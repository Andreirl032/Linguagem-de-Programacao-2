public interface FiguraPlanar {
    float calcularPerimetro();
    float calcularArea();
}
